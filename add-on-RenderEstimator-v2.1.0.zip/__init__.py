import bpy, time

# Global state variables for the current render session.
_frame_start = {}             # {frame_number: start_time}
_total_start = None           # Time when the current render session started.
_first_rendered_frame = None    # The first frame actually rendered in the current session.
_last_frame_time = 0.0        # Duration of last rendered frame.
_last_eta = "AWAITING RENDER"   # Holds the last updated ETA or status message.
_progress = 0.0               # Render progress (0.0–1.0)
_is_rendering = False         # True when a render session is in progress.
_total_time = None            # Total render time (computed on completion)
_avg_time = None              # Average time per frame.
BAR_LENGTH = 25               # Number of characters in progress bar

def format_time(sec):
    """Return a human-friendly string for a duration (in seconds) in long format."""
    sec = int(round(sec))
    if sec < 60:
        return f"{sec} Seconds"
    elif sec < 3600:
        m = sec // 60
        s = sec % 60
        return f"{m} Minutes {s} Seconds"
    elif sec < 86400:
        h = sec // 3600
        m = (sec % 3600) // 60
        s = sec % 60
        return f"{h} Hours {m} Minutes {s} Seconds"
    else:
        d = sec // 86400
        h = (sec % 86400) // 3600
        m = (sec % 3600) // 60
        s = sec % 60
        return f"{d} Days {h} Hours {m} Minutes {s} Seconds"

def format_time_hms(sec):
    """Return a string in HH:MM:SS format."""
    sec = int(round(sec))
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    return f"{h:02d}:{m:02d}:{s:02d}"

def progress_bar(cur, total, show_number=True):
    """Return a text progress bar string.
       If show_number is True, includes the current frame number; otherwise, just the bar."""
    pct = cur / total if total else 0
    filled = int(pct * BAR_LENGTH)
    bar = "█" * filled + "░" * (BAR_LENGTH - filled)
    if show_number:
        return f"{cur}: |{bar}| {pct*100:5.1f}%"
    else:
        return f"|{bar}| {pct*100:5.1f}%"

def redraw_image_editor():
    """Force a redraw of all Image Editor areas (if any windows are available)."""
    wm = bpy.context.window_manager
    if not wm.windows:
        return
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                area.tag_redraw()

def draw_header(self, context):
    """Draws the header items (icon, progress bar, and ETA/status)."""
    scene = context.scene
    layout = self.layout
    row = layout.row(align=True)
    row.alignment = 'RIGHT'

    if _is_rendering and _first_rendered_frame is not None:
        current_frame_index = scene.frame_current - _first_rendered_frame + 1
        total_frames = scene.frame_end - _first_rendered_frame + 1
        # In the header, do not show the frame number.
        pb_text = progress_bar(current_frame_index, total_frames, show_number=False)
        # For the first two frames, show a clock icon; then use the animation icon.
        icon = 'TIME' if current_frame_index <= 2 else 'RENDER_ANIMATION'
        status_msg = _last_eta if _last_eta else "Calculating ETA"
    else:
        pb_text = ""
        status_msg = _last_eta
        icon = 'INFO'

    row.label(text="", icon=icon)
    if pb_text:
        row.label(text=pb_text)
    row.label(text="ETA: " + status_msg)

def render_pre_handler(scene):
    """
    Called before each frame is rendered.
    If no render is active, reinitialize the state—treating the current frame as the first rendered frame.
    Also clears previous session info.
    """
    global _first_rendered_frame, _total_start, _is_rendering, _last_eta, _frame_start, _total_time, _avg_time
    cur = scene.frame_current
    if not _is_rendering:
        _frame_start.clear()
        _total_start = time.time()
        _first_rendered_frame = cur  # Treat the very first rendered frame as the start.
        _is_rendering = True
        _last_eta = "Calculating ETA"
        _total_time = None
        _avg_time = None
    _frame_start[cur] = time.time()
    redraw_image_editor()

def render_post_handler(scene):
    """
    Called after each frame is rendered. Updates ETA and progress.
    The ETA is updated only on frames that satisfy the update interval (frame 3 and every n frames thereafter);
    otherwise, the ETA from the last update is maintained.
    Also prints the progress bar and ETA in HH:MM:SS format to the console.
    """
    global _last_frame_time, _last_eta, _progress
    cur = scene.frame_current
    if _first_rendered_frame is None:
        return  # Safeguard; should not occur.
    frame_index = cur - _first_rendered_frame + 1
    total_frames = scene.frame_end - _first_rendered_frame + 1
    t = time.time() - _frame_start.get(cur, time.time())
    _last_frame_time = t

    if frame_index < 3:
        _last_eta = "Calculating ETA"
    else:
        # Update _last_eta only on update frames.
        if ((frame_index - 3) % scene.rte_settings.update_interval == 0) or frame_index == 3:
            remaining = scene.frame_end - cur
            _last_eta = format_time(t * remaining)
    _progress = frame_index / total_frames
    redraw_image_editor()

    # Print progress bar and ETA in HH:MM:SS format to the console.
    pb_console = progress_bar(frame_index, total_frames, show_number=True)
    eta_hms = format_time_hms(t * (scene.frame_end - cur))
    print(f"[ETA MESSAGE] {pb_console} | ETA (HH:MM:SS): {eta_hms}")

def render_complete_handler(scene):
    """Called when rendering is complete. Updates final render time and status."""
    global _last_eta, _is_rendering, _total_time, _avg_time
    if _first_rendered_frame is None:
        return
    total_frames = scene.frame_end - _first_rendered_frame + 1
    total = time.time() - _total_start if _total_start else 0
    avg = total / total_frames if total_frames else 0
    _total_time = total
    _avg_time = avg
    _last_eta = f"RENDER COMPLETE | Total: {format_time(total)}, Avg: {format_time(avg)}"
    _is_rendering = False
    redraw_image_editor()
    print(f"[ETA MESSAGE] Render complete. Total: {format_time_hms(total)}, Avg per frame: {format_time_hms(avg)}")

def render_cancel_handler(scene):
    """Called if the render is cancelled/stopped. Updates status accordingly."""
    global _last_eta, _is_rendering, _total_time, _avg_time
    _last_eta = "RENDER STOPPED"
    _is_rendering = False
    _total_time = None
    _avg_time = None
    redraw_image_editor()
    print("[ETA MESSAGE] Render cancelled/stopped.")

# --- Property Group for settings ---
class RTE_Settings(bpy.types.PropertyGroup):
    update_interval: bpy.props.IntProperty(
        name="Update Interval",
        description="Frames between ETA updates",
        default=5,
        min=1
    )
    show_debug: bpy.props.BoolProperty(
        name="Print to Console",
        description="Toggle printing ETA messages to the console",
        default=False
    )

# --- Panel definition ---
class RTE_PT_Panel(bpy.types.Panel):
    """UI Panel in the Image Editor sidebar."""
    bl_label = "Render Time Estimator"
    bl_idname = "RTE_PT_panel"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Render ETA'
    
    def draw(self, context):
        layout = self.layout

        # Settings box
        box_settings = layout.box()
        box_settings.label(text="Settings", icon='PREFERENCES')
        settings = context.scene.rte_settings
        box_settings.prop(settings, "update_interval", text="Update Interval (frames)")
        box_settings.prop(settings, "show_debug", text="Print to Console")
        
        # Info box
        box_info = layout.box()
        box_info.label(text="Render Info", icon='INFO')
        if _is_rendering and _first_rendered_frame is not None:
            current_frame_index = context.scene.frame_current - _first_rendered_frame + 1
            total_frames = context.scene.frame_end - _first_rendered_frame + 1
            status_text = f"RENDERING {current_frame_index} of {total_frames} ({_progress*100:5.1f}%)"
        else:
            status_text = _last_eta
        box_info.label(text="Status: " + status_text)
        if _total_time is not None:
            box_info.label(text="Total Time: " + format_time(_total_time))
        if _avg_time is not None:
            box_info.label(text="Avg Time/Frame: " + format_time(_avg_time))
        if _is_rendering:
            box_info.label(text="Last Frame: " + format_time(_last_frame_time))

classes = (RTE_PT_Panel, RTE_Settings)

def register():
    # Reset globals upon registration.
    global _frame_start, _total_start, _first_rendered_frame, _last_frame_time, _last_eta, _progress, _is_rendering, _total_time, _avg_time
    _frame_start = {}
    _total_start = None
    _first_rendered_frame = None
    _last_frame_time = 0.0
    _last_eta = "AWAITING RENDER"
    _progress = 0.0
    _is_rendering = False
    _total_time = None
    _avg_time = None

    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.rte_settings = bpy.props.PointerProperty(type=RTE_Settings)
    bpy.types.IMAGE_HT_header.append(draw_header)
    bpy.app.handlers.render_pre.append(render_pre_handler)
    bpy.app.handlers.render_post.append(render_post_handler)
    bpy.app.handlers.render_complete.append(render_complete_handler)
    bpy.app.handlers.render_cancel.append(render_cancel_handler)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    if hasattr(bpy.types.Scene, "rte_settings"):
        del bpy.types.Scene.rte_settings
    bpy.types.IMAGE_HT_header.remove(draw_header)
    if render_pre_handler in bpy.app.handlers.render_pre:
        bpy.app.handlers.render_pre.remove(render_pre_handler)
    if render_post_handler in bpy.app.handlers.render_post:
        bpy.app.handlers.render_post.remove(render_post_handler)
    if render_complete_handler in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.remove(render_complete_handler)
    if render_cancel_handler in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.remove(render_cancel_handler)

if __name__ == "__main__":
    register()

import bpy
from bpy.app.handlers import persistent
import time

def format_human_time(seconds):
    hours = int(seconds // 3600)
    minutes = max(0, int((seconds % 3600) // 60))
    
    parts = []
    if hours > 0:
        parts.append(f"{hours} Hour{'s' if hours != 1 else ''}")
    if minutes > 0 or hours == 0:
        parts.append(f"{minutes} Minute{'s' if minutes != 1 else ''}")
    
    return " ".join(parts) if parts else "Less than a minute"

def get_ui_progress_bar(progress, width=40):
    progress = max(0, min(100, progress))
    filled = int((progress / 100) * width)
    return f"{'█' * filled}{'░' * (width - filled)}"

@persistent
def render_init(scene):
    scene.render_time_estimator_current_count = 0
    scene.render_time_estimator_elapsed_time = 0.0
    scene.render_time_estimator_total_count = scene.frame_end - scene.frame_start + 1
    scene.render_time_estimator_frame_start_time = 0.0
    scene.render_time_estimator_progress = 0.0

@persistent
def render_pre(scene, dummy):
    scene.render_time_estimator_frame_start_time = time.time()

@persistent
def render_post(scene, dummy):
    current_time = time.time()
    last_frame_time = current_time - scene.render_time_estimator_frame_start_time
    
    scene.render_time_estimator_current_count += 1
    scene.render_time_estimator_elapsed_time += last_frame_time

    total = scene.render_time_estimator_total_count
    current = scene.render_time_estimator_current_count
    
    if total == 0 or current < 2:
        return

    # Calculate estimates
    average_time = scene.render_time_estimator_elapsed_time / current
    remaining_time = (total - current) * average_time
    progress = (current / total) * 100
    scene.render_time_estimator_progress = progress
    
    # Update estimated total time
    scene.render_time_estimator_estimated_total_time = remaining_time + scene.render_time_estimator_elapsed_time

    # Console output
    if scene.render_time_estimator_enable_console:
        interval = scene.render_time_estimator_update_interval
        if (current - 2) % interval == 0:
            current_frame_number = scene.frame_start + current - 1
            progress_bar = f"[{'█' * int(progress/2.5)}{'||' * (40 - int(progress/2.5))}]"
            print(f"Frame {current_frame_number}: {progress_bar} {progress:.1f}% | ETA: {format_human_time(remaining_time)}")

    # Force UI redraw through all windows
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                area.tag_redraw()

class RENDER_PT_TimeEstimator(bpy.types.Panel):
    bl_label = "Render Time Estimator"
    bl_idname = "RENDER_PT_time_estimator"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Render Progress"

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        
        # Settings
        layout.prop(scene, "render_time_estimator_enable_console")
        if scene.render_time_estimator_enable_console:
            layout.prop(scene, "render_time_estimator_update_interval")
        
        # Status display
        if scene.render_time_estimator_current_count > 0:
            box = layout.box()
            
            # Progress bar with percentage
            row = box.row(align=True)
            progress = scene.render_time_estimator_progress
            row.label(text=get_ui_progress_bar(progress))
            row.label(text=f"{progress:.1f}%")
            
            # Detailed information
            row = box.row()
            row.alignment = 'CENTER'
            row.label(text=f"Frame {scene.frame_start + scene.render_time_estimator_current_count - 1}/{scene.frame_end}")
            
            row = box.row(align=True)
            row.label(text=f"Elapsed: {format_human_time(scene.render_time_estimator_elapsed_time)}")
            row.label(text=f"ETA: {format_human_time(scene.render_time_estimator_estimated_total_time - scene.render_time_estimator_elapsed_time)}")

def draw_status_header(self, context):
    if context.scene.render_time_estimator_current_count > 0:
        layout = self.layout
        progress = context.scene.render_time_estimator_progress
        eta = format_human_time(context.scene.render_time_estimator_estimated_total_time - 
                              context.scene.render_time_estimator_elapsed_time)
        layout.label(text=f"Render Progress: {get_ui_progress_bar(progress, 20)} {progress:.1f}% | ETA: {eta}", icon='TIME')

def register():
    bpy.utils.register_class(RENDER_PT_TimeEstimator)
    bpy.types.IMAGE_HT_header.append(draw_status_header)
    
    # Properties
    bpy.types.Scene.render_time_estimator_enable_console = bpy.props.BoolProperty(
        name="Console Output",
        description="Show progress updates in system console",
        default=True
    )
    bpy.types.Scene.render_time_estimator_update_interval = bpy.props.IntProperty(
        name="Update Interval",
        description="Frames between console updates",
        default=5,
        min=1
    )
    bpy.types.Scene.render_time_estimator_current_count = bpy.props.IntProperty(default=0)
    bpy.types.Scene.render_time_estimator_elapsed_time = bpy.props.FloatProperty(default=0.0)
    bpy.types.Scene.render_time_estimator_total_count = bpy.props.IntProperty(default=0)
    bpy.types.Scene.render_time_estimator_frame_start_time = bpy.props.FloatProperty(default=0.0)
    bpy.types.Scene.render_time_estimator_estimated_total_time = bpy.props.FloatProperty(default=0.0)
    bpy.types.Scene.render_time_estimator_progress = bpy.props.FloatProperty(
        name="Progress",
        subtype='PERCENTAGE',
        min=0.0,
        max=100.0,
        default=0.0
    )

    # Handlers
    bpy.app.handlers.render_init.append(render_init)
    bpy.app.handlers.render_pre.append(render_pre)
    bpy.app.handlers.render_post.append(render_post)

def unregister():
    bpy.utils.unregister_class(RENDER_PT_TimeEstimator)
    bpy.types.IMAGE_HT_header.remove(draw_status_header)
    
    # Cleanup
    handlers = [
        (bpy.app.handlers.render_init, render_init),
        (bpy.app.handlers.render_pre, render_pre),
        (bpy.app.handlers.render_post, render_post)
    ]
    for handler_list, func in handlers:
        if func in handler_list:
            handler_list.remove(func)
    
    props = [
        'render_time_estimator_enable_console',
        'render_time_estimator_update_interval',
        'render_time_estimator_current_count',
        'render_time_estimator_elapsed_time',
        'render_time_estimator_total_count',
        'render_time_estimator_frame_start_time',
        'render_time_estimator_estimated_total_time',
        'render_time_estimator_progress'
    ]
    for prop in props:
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)

if __name__ == "__main__":
    register()